package services.impl;

import models.Passager;
import services.PassagerService;

import java.util.List;

public class PassagerServiceImpl implements PassagerService {
    @Override
    public void setPassager(Passager passager) {

    }

    @Override
    public List<Passager> getPassagersList() {
        return null;
    }
}
