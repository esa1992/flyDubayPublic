package services.impl;

import models.Plane;
import services.PlaneService;

import java.util.List;

public class PlaneServiceImpl implements PlaneService {
    @Override
    public void savePlane(Plane plane) {

    }

    @Override
    public List<Plane> getPlanesList() {
        return null;
    }
}
