package services.impl;

import models.Flyght;
import services.FlyghtService;

import java.util.List;

public class FlyghtServiceImpl implements FlyghtService {


    @Override
    public void setFlyght(Flyght flyght) {

    }

    @Override
    public List<Flyght> getFlyghtList() {
        return null;
    }
}
