package services.impl;

import models.City;
import services.CityService;

import java.util.List;

public class CityServiceImpl implements CityService {
    @Override
    public void saveCity(City city) {

    }

    @Override
    public List<City> getCityList() {
        return null;
    }
}
