package services.impl;

import models.Ticket;
import services.TicketService;

import java.util.List;

public class TicketServiceImpl implements TicketService {
    @Override
    public void setTicket(Ticket ticket) {

    }

    @Override
    public List<Ticket> getTicketList() {
        return null;
    }
}
